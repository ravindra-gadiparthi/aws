package org.cloudcafe.aws.s3.services;

import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.cloudcafe.aws.s3.model.Image;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.FileSystemUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

@Service
@AllArgsConstructor
@Slf4j
public class ImageService {

    public static final String BUCKET_NAME = "cloudcafeapp";
    private static String UPLOAD_ROOT = "UPLOAD_DIR";

    private ResourceLoader resourceLoader;

    AmazonS3Client amazonS3Client;


    public Flux<Image> findAllImages() {
        try {
            return Flux.fromIterable(amazonS3Client.listObjects(BUCKET_NAME).getObjectSummaries())
                    .map(objectSummary -> new Image(objectSummary.getBucketName(), objectSummary.getKey()));
        } catch (Exception e) {
            e.printStackTrace();
            return Flux.empty();
        }
    }

    public Mono<S3ObjectInputStream> findOneImage(String imageName) {
        return Mono.fromSupplier(() -> amazonS3Client.getObject(BUCKET_NAME, imageName).getObjectContent());
    }

    public Mono<Void> createImage(Flux<FilePart> files) {

/*        return files.flatMap(filePart -> filePart.transferTo(Paths.get(UPLOAD_ROOT, filePart.filename()))
                .map((done) -> {
                    File file = Paths.get(UPLOAD_ROOT, filePart.filename()).toFile();
                    amazonS3Client.putObject(BUCKET_NAME, filePart.filename(), file);
                    return Mono.empty().then();
                })
        ).then();*/

        return files.flatMap(filePart ->
                filePart.transferTo(Paths.get(UPLOAD_ROOT, filePart.filename()))
                .then(Mono.fromCallable(() -> {
                    log.info("uploading to s3 started");
                    File file = Paths.get(UPLOAD_ROOT, filePart.filename()).toFile();
                    return amazonS3Client.putObject(BUCKET_NAME, filePart.filename(), file);
                }))
                .log("uploading to folder completed"))
                .log("creating image")
                .then();
    }

    public Mono<Void> deleteImage(String fileName) {
        return Mono.fromRunnable(() -> {
            try {
                amazonS3Client.deleteObject(BUCKET_NAME, fileName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }


    @Bean
    private CommandLineRunner init() {
        return (args) -> {
            FileSystemUtils.deleteRecursively(new File(UPLOAD_ROOT));

            Files.createDirectories(Paths.get(UPLOAD_ROOT));
        };
    }
}
