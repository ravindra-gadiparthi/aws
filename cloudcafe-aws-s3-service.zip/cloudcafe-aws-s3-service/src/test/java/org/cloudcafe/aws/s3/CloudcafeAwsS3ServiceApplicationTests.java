package org.cloudcafe.aws.s3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudcafeAwsS3ServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
